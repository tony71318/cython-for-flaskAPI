#!/usr/bin/env python

import os
import codecs


def save_all_real_predict_testing_to_csv(file_name, Y, trY, trPredict_r, trPredict, 
    tsY, tsPredict_r, tsPredict):
    with codecs.open(file_name,'w',encoding="utf-8-sig") as f1:
        f1.write('date,real_diff,predict_diff,real_amount,predict_amount,type\n')
        for i in range(trY.shape[0]):
            f1.write(trY[i][0].astype(str) + ',' + 
                     trY[i][1].astype(str) + ',' + str(trPredict_r[i]) + ',' + 
                     trY[i][3].astype(str) + ',' + str(trPredict[i]) + ',training\n')
        for i in range(trY.shape[0], Y.shape[0]-tsY.shape[0]):
            f1.write(Y[i][0].astype(str) + ',' + 
                     '' + ',' + '' + ',' + 
                     Y[i][3].astype(str) + ',' + '' + ',gap\n')
        for i in range(tsY.shape[0]):
            f1.write(tsY[i][0].astype(str) + ',' + 
                     tsY[i][1].astype(str) + ',' + str(tsPredict_r[i]) + ',' + 
                     tsY[i][3].astype(str) + ',' + str(tsPredict[i]) + ',testing\n')


def save_real_predict_testing_to_csv(file_name, trY, trPredict_r, trPredict, 
    tsY, tsPredict_r, tsPredict):
    with codecs.open(file_name,'w',encoding="utf-8-sig") as f1:
        f1.write('date,real_diff,predict_diff,real_amount,predict_amount,type\n')
        for i in range(trY.shape[0]):
            f1.write(trY[i][0].astype(str) + ',' + 
                     trY[i][1].astype(str) + ',' + str(trPredict_r[i]) + ',' + 
                     trY[i][3].astype(str) + ',' + str(trPredict[i]) + ',training\n')
        for i in range(tsY.shape[0]):
            f1.write(tsY[i][0].astype(str) + ',' + 
                     tsY[i][1].astype(str) + ',' + str(tsPredict_r[i]) + ',' + 
                     tsY[i][3].astype(str) + ',' + str(tsPredict[i]) + ',testing\n')


def save_training_testing_summary_to_csv(file_name, material_id, multistep_ahead, look_back, 
    trRMSE, trMSE, trMAE, trSMAPE, trMAPE, trpRMSE, trpMSE, trpMAE, trpSMAPE, trpMAPE, 
    tsRMSE, tsMSE, tsMAE, tsSMAPE, tsMAPE, tspRMSE, tspMSE, tspMAE, tspSMAPE, tspMAPE, 
    score):
    if not os.path.isfile(file_name):
        with codecs.open(file_name,'w',encoding="utf-8-sig") as f1:
            f1.write('material_id,multistep_ahead,look_back,trdRMSE,trdMSE,trdMAE,trdSMAPE,trdMAPE,trpRMSE,traMSE,traMAE,traSMAPE,traMAPE,tsdRMSE,tsdMSE,tsdMAE,tsdSMAPE,tsdMAPE,tsaRMSE,tsaMSE,tsaMAE,tsaSMAPE,tsaMAPE,score\n')
    with codecs.open(file_name,'a+',encoding="utf-8-sig") as f1:
        f1.write(str(material_id) + ',' + str(multistep_ahead) + ',' + str(look_back) + ',' + 
                 str(trRMSE) + ',' + str(trMSE) + ',' + str(trMAE) + ',' + str(trSMAPE) + ',' + str(trMAPE) + ',' + 
                 str(trpRMSE) + ',' + str(trpMSE) + ',' + str(trpMAE) + ',' + str(trpSMAPE) + ',' + str(trpMAPE) + ',' + 
                 str(tsRMSE) + ',' + str(tsMSE) + ',' + str(tsMAE) + ',' + str(tsSMAPE) + ',' + str(tsMAPE) + ',' +
                 str(tspRMSE) + ',' + str(tspMSE) + ',' + str(tspMAE) + ',' + str(tspSMAPE) + ',' + str(tspMAPE) + ',' + 
                 str(score) + '\n')


def save_training_summary_to_csv(file_name, material_id, multistep_ahead, look_back, 
    trRMSE, trMSE, trMAE, trSMAPE, trMAPE, trpRMSE, trpMSE, trpMAE, trpSMAPE, trpMAPE, pred_type):
    if not os.path.isfile(file_name):
        with codecs.open(file_name,'w',encoding="utf-8-sig") as f1:
            f1.write('material_id,multistep_ahead,look_back,trdRMSE,trdMSE,trdMAE,trdSMAPE,trdMAPE,trpRMSE,traMSE,traMAE,traSMAPE,traMAPE,type\n')
    with codecs.open(file_name,'a+',encoding="utf-8-sig") as f1:
        f1.write(str(material_id) + ',' + str(multistep_ahead) + ',' + str(look_back) + ',' + 
                 str(trRMSE) + ',' + str(trMSE) + ',' + str(trMAE) + ',' + str(trSMAPE) + ',' + str(trMAPE) + ',' + 
                 str(trpRMSE) + ',' + str(trpMSE) + ',' + str(trpMAE) + ',' + str(trpSMAPE) + ',' + str(trpMAPE) + ',' + 
                 pred_type + '\n')


def save_training_testing_opendata_summary_to_csv(
    file_name, material_id, multistep_ahead, look_back, open_data_id, 
    trRMSE, trMSE, trMAE, trSMAPE, trMAPE, trpRMSE, trpMSE, trpMAE, trpSMAPE, trpMAPE, 
    tsRMSE, tsMSE, tsMAE, tsSMAPE, tsMAPE, tspRMSE, tspMSE, tspMAE, tspSMAPE, tspMAPE, score):
    if not os.path.isfile(file_name):
        with codecs.open(file_name,'w',encoding="utf-8-sig") as f1:
            f1.write('material_id,multistep_ahead,look_back,open_data_id,trdRMSE,trdMSE,trdMAE,trdSMAPE,trdMAPE,trpRMSE,traMSE,traMAE,traSMAPE,traMAPE,tsdRMSE,tsdMSE,tsdMAE,tsdSMAPE,tsdMAPE,tsaRMSE,tsaMSE,tsaMAE,tsaSMAPE,tsaMAPE,score\n')
    with codecs.open(file_name,'a+',encoding="utf-8-sig") as f1:
        f1.write(str(material_id) + ',' + str(multistep_ahead) + ',' + str(look_back) + ',' + open_data_id + ',' + 
                 str(trRMSE) + ',' + str(trMSE) + ',' + str(trMAE) + ',' + str(trSMAPE) + ',' + str(trMAPE) + ',' + 
                 str(trpRMSE) + ',' + str(trpMSE) + ',' + str(trpMAE) + ',' + str(trpSMAPE) + ',' + str(trpMAPE) + ',' + 
                 str(tsRMSE) + ',' + str(tsMSE) + ',' + str(tsMAE) + ',' + str(tsSMAPE) + ',' + str(tsMAPE) + ',' +
                 str(tspRMSE) + ',' + str(tspMSE) + ',' + str(tspMAE) + ',' + str(tspSMAPE) + ',' + str(tspMAPE) + ',' + 
                 str(score) + '\n')


def save_training_testing_selected_opendata_summary_to_csv(
    file_name, material_id, multistep_ahead, look_back, open_data_id, 
    trRMSE, trMSE, trMAE, trSMAPE, trMAPE, trpRMSE, trpMSE, trpMAE, trpSMAPE, trpMAPE, 
    tsRMSE, tsMSE, tsMAE, tsSMAPE, tsMAPE, tspRMSE, tspMSE, tspMAE, tspSMAPE, tspMAPE, score):
    if not os.path.isfile(file_name):
        with codecs.open(file_name,'w',encoding="utf-8-sig") as f1:
            f1.write('material_id,multistep_ahead,look_back,open_data_id_1,open_data_id_2,trdRMSE,trdMSE,trdMAE,trdSMAPE,trdMAPE,trpRMSE,traMSE,traMAE,traSMAPE,traMAPE,tsdRMSE,tsdMSE,tsdMAE,tsdSMAPE,tsdMAPE,tsaRMSE,tsaMSE,tsaMAE,tsaSMAPE,tsaMAPE,score\n')
    with codecs.open(file_name,'a+',encoding="utf-8-sig") as f1:
        f1.write(str(material_id) + ',' + str(multistep_ahead) + ',' + str(look_back) + ',' + 
                 open_data_id[1] + ',' + '' + ',' + 
                 str(trRMSE) + ',' + str(trMSE) + ',' + str(trMAE) + ',' + str(trSMAPE) + ',' + str(trMAPE) + ',' + 
                 str(trpRMSE) + ',' + str(trpMSE) + ',' + str(trpMAE) + ',' + str(trpSMAPE) + ',' + str(trpMAPE) + ',' + 
                 str(tsRMSE) + ',' + str(tsMSE) + ',' + str(tsMAE) + ',' + str(tsSMAPE) + ',' + str(tsMAPE) + ',' +
                 str(tspRMSE) + ',' + str(tspMSE) + ',' + str(tspMAE) + ',' + str(tspSMAPE) + ',' + str(tspMAPE) + ',' + str(score) + '\n')


def save_summary_result_to_csv(file_name, material_id, multistep_ahead, look_back, trMAPE, trRMSE, tsMAPE, tsRMSE, score):
    if not os.path.isfile(file_name):
        with codecs.open(file_name,'w',encoding="utf-8-sig") as f1:
            f1.write('material_id,multistep_ahead,look_back,trRMSE,trMAPE,tsRMSE,tsMAPE,score\n')
    with codecs.open(file_name,'a+',encoding="utf-8-sig") as f1:
        f1.write(str(material_id) + ',' + str(multistep_ahead) + ',' + str(look_back) + ',' + 
                 str(trRMSE) + ',' + str(trMAPE) + ',' + str(tsRMSE) + ',' + str(tsMAPE) + ',' + str(score) + '\n')


def save_summary_opendata_result_to_csv(file_name, material_id, multistep_ahead, look_back, open_data_id, trMAPE, trRMSE, tsMAPE, tsRMSE):
    if not os.path.isfile(file_name):
        with codecs.open(file_name,'w',encoding="utf-8-sig") as f1:
            f1.write('material_id,multistep_ahead,look_back,open_data_id,trRMSE,trMAPE,tsRMSE,tsMAPE\n')
    with codecs.open(file_name,'a+',encoding="utf-8-sig") as f1:
        f1.write(str(material_id) + ',' + str(multistep_ahead) + ',' + str(look_back) + ',' + open_data_id + ',' + 
                 str(trRMSE) + ',' + str(trMAPE) + ',' + str(tsRMSE) + ',' + str(tsMAPE) + '\n')


def save_summary_opendata_score_result_to_csv(file_name, material_id, multistep_ahead, look_back, open_data_id, trMAPE, trRMSE, tsMAPE, tsRMSE, score):
    if not os.path.isfile(file_name):
        with codecs.open(file_name,'w',encoding="utf-8-sig") as f1:
            f1.write('material_id,multistep_ahead,look_back,open_data_id,trRMSE,trMAPE,tsRMSE,tsMAPE,score\n')
    with codecs.open(file_name,'a+',encoding="utf-8-sig") as f1:
        f1.write(str(material_id) + ',' + str(multistep_ahead) + ',' + str(look_back) + ',' + open_data_id + ',' + 
                 str(trRMSE) + ',' + str(trMAPE) + ',' + str(tsRMSE) + ',' + str(tsMAPE) + ',' + str(score) + '\n')


def save_summary_selected_opendata_score_result_to_csv(file_name, material_id, multistep_ahead, look_back, open_data_id, trMAPE, trRMSE, tsMAPE, tsRMSE, score):
    if not os.path.isfile(file_name):
        with codecs.open(file_name,'w',encoding="utf-8-sig") as f1:
            f1.write('material_id,multistep_ahead,look_back,open_data_id_1,open_data_id_2,trRMSE,trMAPE,tsRMSE,tsMAPE,score\n')
    with codecs.open(file_name,'a+',encoding="utf-8-sig") as f1:
        f1.write(str(material_id) + ',' + str(multistep_ahead) + ',' + str(look_back) + ',' + 
                 open_data_id[1] + ',' + '' + ',' + 
                 str(trRMSE) + ',' + str(trMAPE) + ',' + str(tsRMSE) + ',' + str(tsMAPE) + ',' + str(score) + '\n')


def save_feature_set_to_csv(file_name, material_id, multistep_ahead, look_back, n_features, feature_set):
    if not os.path.isfile(file_name):
        with codecs.open(file_name,'w',encoding="utf-8-sig") as f1:
            f1.write('material_id,multistep_ahead,look_back,n_features,feature_set\n')
    with codecs.open(file_name,'a+',encoding="utf-8-sig") as f1:
        f1.write(str(material_id) + ',' + str(multistep_ahead) + ',' + str(look_back) + ',' + 
                 str(n_features) + ',' + str(feature_set) + '\n')


def save_summary_each_model_result_to_csv(file_name, material_id, TRMAPE, TSMAPE):
    if not os.path.isfile(file_name):
        with codecs.open(file_name,'w',encoding="utf-8-sig") as f1:
            f1.write('material_id,trMAPE_1,tsMAPE_1,trMAPE_2,tsMAPE_2,trMAPE_3,tsMAPE_3,trMAPE_4,tsMAPE_4,trMAPE_5,tsMAPE_5,trMAPE_6,tsMAPE_6\n')
    with codecs.open(file_name,'a+',encoding="utf-8-sig") as f1:
        f1.write(str(material_id) + ',' + 
                 str(TRMAPE[0]) + ',' + str(TSMAPE[0]) + ',' + 
                 str(TRMAPE[1]) + ',' + str(TSMAPE[1]) + ',' + 
                 str(TRMAPE[2]) + ',' + str(TSMAPE[2]) + ',' + 
                 str(TRMAPE[3]) + ',' + str(TSMAPE[3]) + ',' + 
                 str(TRMAPE[4]) + ',' + str(TSMAPE[4]) + ',' + 
                 str(TRMAPE[5]) + ',' + str(TSMAPE[5]) + '\n')


def save_summary_every_month_result_to_csv(file_name, material_id, tx_dt, tr_MAPE, real_sum, predict_sum, tr_sum_MPE):
    if not os.path.isfile(file_name):
        with codecs.open(file_name,'w',encoding="utf-8-sig") as f1:
            f1.write('material_id,tx_dt,tr_MAPE,real_sum,predict_sum,tr_sum_MPE\n')
    with codecs.open(file_name,'a+',encoding="utf-8-sig") as f1:
        f1.write(str(material_id) + ',' + tx_dt + ',' + 
                 str(tr_MAPE) + ',' + str(real_sum) + ',' + 
                 str(predict_sum) + ',' + str(tr_sum_MPE) + '\n')
