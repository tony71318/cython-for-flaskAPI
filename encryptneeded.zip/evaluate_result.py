#!/usr/bin/env python

import math
import numpy
import logging
from sklearn import preprocessing
from sklearn.metrics import mean_squared_error, mean_absolute_error, accuracy_score
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import confusion_matrix


def mean_absolute_percentage_error(y_true, y_pred):
    idx = y_true != 0.0
    return 100*numpy.mean(numpy.abs(y_pred[idx]-y_true[idx])/numpy.abs(y_true[idx]))


def symmetric_mean_absolute_percentage_error(y_true, y_pred):
    idx = numpy.ones_like(y_true, dtype=bool)
    return 100*numpy.mean(numpy.abs(y_pred[idx]-y_true[idx])/(numpy.abs(y_true[idx])+numpy.abs(y_pred[idx]))/2)


def evaluate_regression_result(real, predict):
    #calculate root mean squared error
    RMSE = math.sqrt(mean_squared_error(real, predict))
    #print ('RMSE: %.4f' % (RMSE))
    #logging.debug("RMSE: {0}".format(RMSE))

    #calculate mean squared error
    MSE = mean_squared_error(real, predict)
    #print ('MSE: %.4f' % (MSE))
    #logging.debug("MSE: {0}".format(MSE))

    #calculate mean absolute error
    MAE = mean_absolute_error(real, predict)
    #print ('MAE: %.4f' % (MAE))
    #logging.debug("MAE: {0}".format(MAE))

    #calculate symmetric mean absolute percentage error
    SMAPE = symmetric_mean_absolute_percentage_error(real, predict)
    #print ('SMAPE: %.4f' % (SMAPE))
    #logging.debug("SMAPE: {0}".format(SMAPE))

    #calculate mean absolute percentage error
    MAPE = mean_absolute_percentage_error(real, predict)
    #print ('MAPE: %.4f' % (MAPE))
    #logging.debug("MAPE: {0}".format(MAPE))

    return MSE, RMSE, MAE, SMAPE, MAPE
