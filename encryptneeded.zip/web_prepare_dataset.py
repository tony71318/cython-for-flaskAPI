#!/usr/bin/env python
from __future__ import division

import os
import sys
import glob
import numpy
import pandas
import codecs
import datetime
import pickle

##function name
# read_data_from_csv
# create_training_testing_dataset_x_diff_y_diff
# create_training_testing_dataset_y_diff
# create_training_testing_dataset_x_diff_y_mean
# create_training_testing_dataset_y_mean
# create_training_testing_dataset
# normalize_data


def read_data_from_csv(file_name):
    print('read csv file')
    return pandas.read_csv(file_name, 
                           sep=",", 
                           engine='python')


def create_training_testing_dataset_x_diff_y_diff(dataset, open_dataset, 
    look_back, multistep_ahead, 
    training_end, testing_start):
    # print(dataset)
    trX = []
    trY = []
    tsX = []
    tsY = []
    Y = []
    for i in range(0,len(dataset)-look_back+1):
        # if (i + look_back + multistep_ahead - 1) <= (len(dataset)-1):
        if (i + look_back - 1) <= (len(dataset)-1):
            x = []
            for j in range(look_back):
                x = x + [dataset[i+j, 2] - dataset[i+j-1, 2]]
                if open_dataset is not None:
                    for k in range(1,len(open_dataset[0])):
                        x = x + [open_dataset[i+j, k] - open_dataset[i+j-1, k]]

            try:
                t_date = dataset[i + look_back - 1, 1]
            except:
                raise

            current_value = dataset[i + look_back - 1, 2]
            # ahead_value = dataset[i + look_back + multistep_ahead - 1, 2]

            # y = [t_date, ahead_value-current_value, current_value, ahead_value]
            y = [t_date, -1, current_value, -1]
            Y.append(y)
            # if datetime.datetime.strptime(t_date, "%Y-%m-%d") <= datetime.datetime.strptime(training_end, "%Y-%m-%d"):
            #     trX.append(x)
            #     trY.append(y)
            if datetime.datetime.strptime(t_date, "%Y-%m-%d") >= datetime.datetime.strptime(testing_start, "%Y-%m-%d"):
                tsX.append(x)
                tsY.append(y)

    trX = numpy.array(trX)
    trY = numpy.array(trY)
    tsX = numpy.array(tsX)
    tsY = numpy.array(tsY)
    Y = numpy.array(Y)

    return trX, trY, tsX, tsY, Y


def create_training_testing_dataset_y_diff(dataset, open_dataset, 
    look_back, multistep_ahead, 
    training_end, testing_start):
    #print dataset
    trX = []
    trY = []
    tsX = []
    tsY = []
    Y = []
    for i in range(0,len(dataset)-look_back+1):
        # if (i + look_back + multistep_ahead - 1) <= (len(dataset)-1):
        if (i + look_back - 1) <= (len(dataset)-1):
            x = []
            for j in range(look_back):
                x = x + [dataset[i+j, 2]]
                if open_dataset is not None:
                    for k in range(1,len(open_dataset[0])):
                        x = x + [open_dataset[i+j, k]]

            try:
                t_date = dataset[i + look_back - 1, 1]
            except:
                raise

            current_value = dataset[i + look_back - 1, 2]
            # ahead_value = dataset[i + look_back + multistep_ahead - 1, 2]

            # y = [t_date, ahead_value-current_value, current_value, ahead_value]
            y = [t_date, -1, current_value, -1]
            Y.append(y)
            # if datetime.datetime.strptime(t_date, "%Y-%m-%d") <= datetime.datetime.strptime(training_end, "%Y-%m-%d"):
            #     trX.append(x)
            #     trY.append(y)
            if datetime.datetime.strptime(t_date, "%Y-%m-%d") >= datetime.datetime.strptime(testing_start, "%Y-%m-%d"):
                tsX.append(x)
                tsY.append(y)

    trX = numpy.array(trX)
    trY = numpy.array(trY)
    tsX = numpy.array(tsX)
    tsY = numpy.array(tsY)
    Y = numpy.array(Y)

    return trX, trY, tsX, tsY, Y


def create_training_testing_dataset_x_diff_y_mean(dataset, open_dataset, 
    look_back, multistep_ahead, 
    training_end, testing_start):
    #print dataset
    trX = []
    trY = []
    tsX = []
    tsY = []
    Y = []
    amount = []
    for i in range(len(dataset)):
        if datetime.datetime.strptime(dataset[i, 1], "%Y-%m-%d") < datetime.datetime.strptime(testing_start, "%Y-%m-%d"):
            amount.append(dataset[i, 2])
    material_mean = numpy.mean(numpy.array(amount), axis=0)
    material_std = numpy.std(numpy.array(amount), axis=0)
    
    for i in range(0,len(dataset)-look_back+1):
        # if (i + look_back + multistep_ahead - 1) <= (len(dataset)-1):
        if (i + look_back - 1) <= (len(dataset)-1):
            x = []
            for j in range(look_back):
                x = x + [dataset[i+j, 2] - dataset[i+j-1, 2]]
                if open_dataset is not None:
                    for k in range(1,len(open_dataset[0])):
                        x = x + [open_dataset[i+j, k] - open_dataset[i+j-1, k]]

            try:
                t_date = dataset[i + look_back - 1, 1]
            except:
                raise

            current_value = dataset[i + look_back - 1, 2]
            # ahead_value = dataset[i + look_back + multistep_ahead - 1, 2]
            y = [t_date, -1, material_mean, -1]
            Y.append(y)
            # if datetime.datetime.strptime(t_date, "%Y-%m-%d") <= datetime.datetime.strptime(training_end, "%Y-%m-%d"):
            #     if (ahead_value-material_mean) < 2*material_std:
            #         trX.append(x)
            #         trY.append(y)
            if datetime.datetime.strptime(t_date, "%Y-%m-%d") >= datetime.datetime.strptime(testing_start, "%Y-%m-%d"):
                tsX.append(x)
                tsY.append(y)

    trX = numpy.array(trX)
    trY = numpy.array(trY)
    tsX = numpy.array(tsX)
    tsY = numpy.array(tsY)
    Y = numpy.array(Y)


    return trX, trY, tsX, tsY, Y


def create_training_testing_dataset_y_mean(dataset, open_dataset, 
    look_back, multistep_ahead, 
    training_end, testing_start):
    #print dataset
    trX = []
    trY = []
    tsX = []
    tsY = []
    Y = []
    material_sum = 0
    material_count = 0
    for i in range(len(dataset)):
        if datetime.datetime.strptime(dataset[i, 1], "%Y-%m-%d") < datetime.datetime.strptime(testing_start, "%Y-%m-%d"):
            material_sum += dataset[i, 2]
            material_count += 1
    material_mean = material_sum / material_count

    for i in range(0,len(dataset)-look_back+1):
        # if (i + look_back + multistep_ahead - 1) <= (len(dataset)-1):
        if (i + look_back - 1) <= (len(dataset)-1):
            x = []
            for j in range(look_back):
                x = x + [dataset[i+j, 2]]
                if open_dataset is not None:
                    for k in range(1,len(open_dataset[0])):
                        x = x + [open_dataset[i+j, k]]

            try:
                t_date = dataset[i + look_back - 1, 1]
            except:
                raise

            current_value = dataset[i + look_back - 1, 2]
            # ahead_value = dataset[i + look_back + multistep_ahead - 1, 2]

            y = [t_date, -1, material_mean, -1]
            Y.append(y)
            # if datetime.datetime.strptime(t_date, "%Y-%m-%d") <= datetime.datetime.strptime(training_end, "%Y-%m-%d"):
            #     trX.append(x)
            #     trY.append(y)
            if datetime.datetime.strptime(t_date, "%Y-%m-%d") >= datetime.datetime.strptime(testing_start, "%Y-%m-%d"):
                tsX.append(x)
                tsY.append(y)

    trX = numpy.array(trX)
    trY = numpy.array(trY)
    tsX = numpy.array(tsX)
    tsY = numpy.array(tsY)
    Y = numpy.array(Y)

    return trX, trY, tsX, tsY, Y


def create_training_testing_dataset(dataset, open_dataset, 
    look_back, multistep_ahead, 
    training_end, testing_start, 
    x_method, y_method):
    if x_method == 'x_diff' and y_method == 'y_diff':
        trX, trY, tsX, tsY, Y = create_training_testing_dataset_x_diff_y_diff(
            dataset, 
            open_dataset, 
            look_back, 
            multistep_ahead, 
            training_end, 
            testing_start)
    elif x_method == 'x' and y_method == 'y_diff':
        trX, trY, tsX, tsY, Y = create_training_testing_dataset_y_diff(
            dataset, 
            open_dataset, 
            look_back, 
            multistep_ahead, 
            training_end, 
            testing_start)
    elif x_method == 'x_diff' and y_method == 'y_mean':
        trX, trY, tsX, tsY, Y = create_training_testing_dataset_x_diff_y_mean(
            dataset, 
            open_dataset, 
            look_back, 
            multistep_ahead, 
            training_end, 
            testing_start)
    else:
        trX, trY, tsX, tsY, Y = create_training_testing_dataset_y_mean(
            dataset, 
            open_dataset, 
            look_back, 
            multistep_ahead, 
            training_end, 
            testing_start)

    return trX, trY, tsX, tsY, Y


def normalize_data(_, tsX, info):
    path = os.path.join('./uploads', 'normalize_info.pickle')
    file = open(path, 'rb')
    _dict = pickle.load(file)
    file.close()

    key = '{}_{}_{}_{}'.format(info[0], info[1], info[2], info[3])

    max_value = _dict[key][0]
    min_value = _dict[key][1]

    tsX_normalize = []
    for i in range(len(tsX)):
        tmp = []
        for j in range(len(tsX[i])):
            if max_value[j] == 0 and min_value[j] == 0:
                tmp.append(tsX[i][j])
            else:
                tmp.append((tsX[i][j] - min_value[j]) / (max_value[j] - min_value[j]))
        tsX_normalize.append(tmp)
    tsX_normalize = numpy.array(tsX_normalize)

    return tsX_normalize, tsX_normalize
