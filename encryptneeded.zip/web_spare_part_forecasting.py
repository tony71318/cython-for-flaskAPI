﻿# -*- coding: utf-8 -*-
#!/usr/bin/env python
from __future__ import division

import matplotlib as mpl
mpl.use('Agg')

import matplotlib.pyplot as plt

import os
import sys
import time
import numpy
import pandas
import math
import logging
import json
import codecs
import datetime
from datetime import timedelta

from sklearn.externals import joblib
import base64
from io import BytesIO
import importlib

from py.main.web_config import *
from py.main.web_prepare_dataset import *
from py.main.evaluate_result import *
from py.main.save_result import *

import warnings
warnings.filterwarnings('ignore')

if not os.path.exists('log'):
    os.makedirs('log')
log_path = os.path.join('./log', 
                        'taipower_regression.log')

logging.basicConfig(filename=log_path,level=logging.DEBUG)


def my_custom_loss_func(y_true, y_pred):
    idx = y_true != 0.0
    return 100*numpy.mean(numpy.abs(y_pred[idx]-y_true[idx])/numpy.abs(y_true[idx]))


def main(material_id, multistep_ahead, predict_start):
    st = datetime.datetime.now()
    open_data_id = OPEN_DATA_IDS[material_id][multistep_ahead-1]
    look_back = LOOK_BACK[material_id][multistep_ahead-1]
    ml_method = ML_METHODS[material_id]
    x_method = X_METHODS[material_id]
    y_method = Y_METHODS[material_id]
    
    print('material_id: ' + str(material_id) + ', open_data_id: ' + str(open_data_id))
    print('multistep_ahead: ' + str(multistep_ahead) + ', look_back: ' + str(look_back))
    print('ml_method: ' + str(ml_method) + ', x_method: ' + str(x_method) + ', y_method: ' + str(y_method))
    logging.debug("material_id={0}!".format(material_id))
    logging.debug("open_data_id={0}!".format(open_data_id))
    logging.debug("multistep_ahead={0}!".format(multistep_ahead))
    logging.debug("ml_method={0}!".format(ml_method))
    logging.debug("x_method={0}!".format(x_method))
    logging.debug("y_method={0}!".format(y_method))

    csv_file_name = './uploads/material_amount.csv'
    dataframe = read_data_from_csv(csv_file_name)
    # MATERIAL_ID, TXDATE, AMOUNT
    df = dataframe.loc[dataframe['MATERIAL_ID'] == material_id]
    df = df.loc[:, ~df.columns.str.match('Unnamed')]
    df = df.sort_values(by=['TXDATE'])
    dataset = df.values

    if open_data_id[1] != 'NONE':
        open_csv_file_name = './uploads/open_data.csv'
        open_dataframe = read_data_from_csv(open_csv_file_name)
        # TXDATE, XXX
        open_df = open_dataframe[open_data_id]
        #print open_df

        open_dataset = open_df.values
        # if len(dataset) != len(open_dataset):
        #     list_dataset = list(dataset)
        #     list_dataset.append([dataset[-1,0], open_dataset[-1,0], 0])
        #     dataset = numpy.asarray(list_dataset)
        #     print('append zero to the latest row')
        if len(dataset) != len(open_dataset):
            print(len(dataset), len(open_dataset))
            print('len(dataset) != len(open_dataset)')
            sys.exit(0)
    else:
        open_dataset = None

    # decide by predict_start
    if datetime.datetime.strptime(predict_start, "%Y-%m-%d").date() > datetime.date(2018, 6, 1):
        LATEST_YEAR = 2018
        PERIOD_YEAR = 2
    elif datetime.datetime.strptime(predict_start, "%Y-%m-%d").date() <= datetime.date(2018, 6, 1) and datetime.datetime.strptime(predict_start, "%Y-%m-%d").date() > datetime.date(2017, 12, 1):
        LATEST_YEAR = 2018
        PERIOD_YEAR = 1
    elif datetime.datetime.strptime(predict_start, "%Y-%m-%d").date() <= datetime.date(2017, 12, 1) and datetime.datetime.strptime(predict_start, "%Y-%m-%d").date() > datetime.date(2017, 6, 1):
        LATEST_YEAR = 2017
        PERIOD_YEAR = 2
    else:
        LATEST_YEAR = 2017
        PERIOD_YEAR = 1

    training_end_list, testing_start_list = getSplitTime(predict_start)
    training_end = training_end_list[multistep_ahead-1]
    testing_start = testing_start_list[multistep_ahead-1]

    trX, trY, tsX, tsY, Y = create_training_testing_dataset(
        dataset, 
        open_dataset, 
        look_back, 
        multistep_ahead, 
        training_end, 
        testing_start, 
        x_method, 
        y_method)

    info = [material_id, LATEST_YEAR, PERIOD_YEAR, multistep_ahead]
    trX, tsX = normalize_data(tsX, tsX, info) # TODO: need trX's max min
        
    print ('trX shape: ' + str(trX.shape))
    print ('tsX shape: ' + str(tsX.shape))

    # trD = numpy.reshape(trY[:,1].astype(float), 
    #                     trY[:,1].shape[0])
    # #print (trD)
    # #print (trD.shape)
    # #print (trX.shape)
    # trCP = numpy.reshape(trY[:,2].astype(float), 
    #                      trY[:,2].shape[0])
    # trAP = numpy.reshape(trY[:,3].astype(float), 
    #                      trY[:,3].shape[0])
    # tsD = numpy.reshape(tsY[:,1].astype(float), 
    #                     tsY[:,1].shape[0])
    # tsCP = numpy.reshape(tsY[:,2].astype(float), 
    #                      tsY[:,2].shape[0])
    # tsAP = numpy.reshape(tsY[:,3].astype(float), 
    #                      tsY[:,3].shape[0])

    model_file_name = '{}_model.{}_{}_{}_{}_{}'.format(LATEST_YEAR, 
                                                            getEncodedNumber(LATEST_YEAR),
                                                            getEncodedNumber(PERIOD_YEAR),
                                                            getEncodedNumber(material_id),
                                                            getEncodedNumber(multistep_ahead),
                                                            ml_method)

    module = importlib.import_module('py.pkl.' + model_file_name)
    enc_model = getattr(module, 'enc_model')
    byteArray = base64.b64decode(enc_model)
    model = joblib.load(BytesIO(byteArray))

    logging.debug("make predictions")
    trY_pred = []
    trAP_predict = []

    tsY_pred = model.predict(tsX)
    # ts_mse, ts_rmse, ts_mae, ts_smape, ts_mape = evaluate_regression_result(tsD, tsY_pred)
    # print("testing amount difference MSE: %.4f" % ts_mse)
    # print("testing amount difference RMSE: %.4f" % ts_rmse)
    # print("testing amount difference MAE: %.4f" % ts_mae)
    # print("testing amount difference SMAPE: %.4f" % ts_smape)
    # print("testing amount difference MAPE: %.4f" % ts_mape)
    tsAP_predict = []
    for i in range(tsY.shape[0]):
        tmp = tsY_pred[i] + tsY[i][2].astype(float)
        if tmp < 0:
            print('=======' + str(tmp) + '=======')
            tsAP_predict.append(0.0)
        else:
            tsAP_predict.append(tmp)
    tsAP_predict = numpy.array(tsAP_predict)
    # ts_ap_mse, ts_ap_rmse, ts_ap_mae, ts_ap_smape, ts_ap_mape = evaluate_regression_result(tsAP, tsAP_predict)
    # print("testing ahead amount MSE: %.4f" % ts_ap_mse)
    # print("testing ahead amount RMSE: %.4f" % ts_ap_rmse)
    # print("testing ahead amount MAE: %.4f" % ts_ap_mae)
    # print("testing ahead amount SMAPE: %.4f" % ts_ap_smape)
    # print("testing ahead amount MAPE: %.4f" % ts_ap_mape)

    if not os.path.exists('{}_result'.format(LATEST_YEAR)):
        os.makedirs('{}_result'.format(LATEST_YEAR))
    predict_csv_file_name = os.path.join('./result/{}_{}_real_predict_testing.csv'.format(material_id, 
                                                                                        multistep_ahead,))
    save_all_real_predict_testing_to_csv(predict_csv_file_name, Y, 
                                     trY, trY_pred, trAP_predict, 
                                     tsY, tsY_pred, tsAP_predict)

def predictID(_id, predict_start):
    for j in range(len(multistep_ahead_list)):
        main(_id, multistep_ahead_list[j], predict_start) # need predict_start

if __name__=='__main__':

    for i in range(len(MATERIAL_IDS)):
        for j in range(len(multistep_ahead_list)):
            main(MATERIAL_IDS[i], multistep_ahead_list[j]) # need predict_start

    print('done')
